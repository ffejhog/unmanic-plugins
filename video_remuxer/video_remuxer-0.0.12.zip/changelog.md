
**<span style="color:#56adda">0.0.12</span>**
- Plugin should throw an exception when FFmpeg is not correctly installed
- Prevent HEVC codec support on AVI
- Prevent ttf codec support on MP4

**<span style="color:#56adda">0.0.11</span>**
- Remove ARIB STD-B24 subtitle support from avi, mkv, mp4 destination containers

**<span style="color:#56adda">0.0.10</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.9</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.8</span>**
- Fix for error when the stream info does not contain a particular attribute

**<span style="color:#56adda">0.0.7</span>**
- Remove all data streams for a remux to MKV

**<span style="color:#56adda">0.0.6</span>**
- Remove PGS subs from the list of sub codecs supported by MP4 containers

**<span style="color:#56adda">0.0.5</span>**
- Transcode or remove streams which are not compatible with destination container

**<span style="color:#56adda">0.0.4</span>**
- Fix issue where the file out was not being modified correctly

**<span style="color:#56adda">0.0.3</span>**
- Limit plugin to only process files with a "video" mimetype

**<span style="color:#56adda">0.0.2</span>**
- Set teh initial flow position

**<span style="color:#56adda">0.0.1</span>**
- Initial version
