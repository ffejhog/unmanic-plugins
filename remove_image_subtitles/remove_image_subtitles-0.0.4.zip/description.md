
This is useful if you are converting to a container format that does not support these image subtitles,
or you wish to supply your own text based subtitles.

This plugin currently matches with and removes streams with the following codecs:

- **dvbsub**
- **dvdsub**
- **pgssub**
- **xsub**

If I have missed some, or you want another one added, open an issue against the Plugin repo on GitHub.
