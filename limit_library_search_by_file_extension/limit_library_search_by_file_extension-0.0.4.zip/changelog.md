
**<span style="color:#56adda">0.0.4</span>**
- Fix issue where the plugin was never ignoring files without an extension such as the '.unmanic' files

**<span style="color:#56adda">0.0.3</span>**
- Add ability to force all matching files to be added to the pending task queue
- Remove support for Unmanic v1 PluginHandler compatibility

**<span style="color:#56adda">0.0.2</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.1</span>**
- Initial version
