# Skip commercials in TV show - Comskip

plugin for [Unmanic](https://github.com/Unmanic)
