# Ignore files in the completed tasks list

plugin for [Unmanic](https://github.com/Unmanic)
